<?php

namespace App\Repositories\Conference;

interface ConferenceInterface
{

}
