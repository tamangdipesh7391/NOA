<?php

namespace App\Repositories\Conference;

class ConferenceRepository
{

}
