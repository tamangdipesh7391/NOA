<?php

require_once dirname(__FILE__) . '/routing/frontend.php';
require_once dirname(__FILE__) . '/routing/backend.php';

