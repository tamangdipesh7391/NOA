

<?php $__env->startSection('member-content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2><i class="fa fa-edit"></i> Update General Info</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                       aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#">Settings 1</a>
                                        <a class="dropdown-item" href="#">Settings 2</a>
                                    </div>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="col-md-12">
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="name">Name:
                                                        <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('name')); ?></a>
                                                    </label>
                                                    <input type="text" name="name" id="name"
                                                           placeholder="Full name"
                                                           value="<?php echo e($userData->name); ?>"
                                                           class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="gender">Gender:
                                                        <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('gender')); ?></a>
                                                    </label>
                                                    <select name="gender" id="gender"
                                                            class="form-control">
                                                        <option value="" selected readonly>Select Gender</option>
                                                        <option
                                                            value="male" <?php echo e($userData->gender=='male'?'selected':''); ?>>
                                                            Male
                                                        </option>
                                                        <option
                                                            value="female" <?php echo e($userData->gender=='female'?'selected':''); ?>>
                                                            Female
                                                        </option>
                                                    </select>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="email">Email:
                                                        <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('email')); ?></a>
                                                    </label>
                                                    <input type="email" name="email" id="email"
                                                           placeholder="Enter email"
                                                           value="<?php echo e($userData->email); ?>"
                                                           class="form-control">

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="phone">Phone:
                                                        <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('phone')); ?></a>
                                                    </label>
                                                    <input type="text" name="phone" id="phone"
                                                           value="<?php echo e($userData->phone); ?>"
                                                           class="form-control">

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="dob">Date of Birth:
                                                        <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('dob')); ?></a>
                                                    </label>
                                                    <input type="date" name="date_of_birth" id="dob"
                                                           value="<?php echo e($userData->date_of_birth); ?>"
                                                           class="form-control">
                                                </div>
                                            </div>

                                        </div>


                                        <div class="row">
                                            <div class="col-md-12">
                                                <h3>Member Types:</h3>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="member_type_id">Select member type:
                                                        <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('front_size')); ?></a>
                                                    </label>
                                                    <select name="membership_type_id" id="member_type_id"
                                                            class="form-control">
                                                        <option value="<?php echo e($userData->memberType->id); ?>">
                                                            <?php echo e($userData->memberType->type); ?>

                                                        </option>
                                                        <?php $__currentLoopData = $memberTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($type->id); ?>"
                                                                <?php echo e(old('membership_type_id')==$type->id ? 'selected':''); ?>

                                                            ><?php echo e($type->type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php $__currentLoopData = $memberTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <h1 class="is-size-5"><?php echo e($type->type); ?>

                                                            : <?php echo e($type->price); ?></h1>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <button class="btn btn-success">
                                                    <i class="fa fa-plus" aria-hidden="true"></i> Update Account
                                                </button>
                                            </div>
                                        </div>


                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.members.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/members/update/general-info.blade.php ENDPATH**/ ?>