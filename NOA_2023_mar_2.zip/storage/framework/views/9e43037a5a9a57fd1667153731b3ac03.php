
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-4 mb-2">
                            <h1>
                                <i class="bi bi-bag-plus-fill"></i>
                                Manage Country
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <?php if($editCountryData): ?>
                                <form action="<?php echo e(route('manage-address').'/'.$editCountryData->id); ?>"
                                      method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="name">Country name:
                                            <a style="color: red;"><?php echo e($errors->first('country_name')); ?></a>
                                        </label>
                                        <input type="text" name="country_name"
                                               value="<?php echo e($editCountryData->country_name); ?>"
                                               id="name"
                                               class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="code">Country Code:
                                            <a style="color: red;"><?php echo e($errors->first('code')); ?></a>
                                        </label>
                                        <input type="text" name="code" value="<?php echo e($editCountryData->code); ?>"
                                               id="code"
                                               class="form-control">
                                    </div>
                                    <div class="form group">
                                        <button class="btn btn-success">
                                            <i class="fa fa-edit"></i> Update Country
                                        </button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('manage-address')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="name">Country name:
                                            <a style="color: red;"><?php echo e($errors->first('country_name')); ?></a>
                                        </label>
                                        <input type="text" name="country_name" value="<?php echo e(old('country_name')); ?>" id="name"
                                               class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="code">Country Code:
                                            <a style="color: red;"><?php echo e($errors->first('code')); ?></a>
                                        </label>
                                        <input type="text" name="code" value="<?php echo e(old('code')); ?>" id="code"
                                               class="form-control">
                                    </div>
                                    <div class="form group">
                                        <button class="btn btn-success">
                                            <i class="fa fa-plus"></i> Add Country
                                        </button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-8">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <td>S.n</td>
                                    <td>Name</td>
                                    <td>Code</td>
                                    <td>Action</td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $countryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($country->country_name); ?>

                                            <hr>
                                            <a href="<?php echo e(route('manage-province',$country->id)); ?>">Total
                                                Province: <?php echo e($country->province->count()); ?></a>

                                        </td>
                                        <td><?php echo e($country->code); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('manage-address').'/'.$country->id); ?>"
                                               class="btn btn-success">
                                                <i class="fa fa-edit"></i> Edit</a>
                                            <a href="<?php echo e(route('delete-country',$country->id)); ?>"
                                               class="btn btn-danger">
                                                <i class="fa fa-trash"></i> Delete</a>
                                            <a href="<?php echo e(route('manage-province',$country->id)); ?>" class="btn btn-success">
                                                <i class="fa fa-plus"></i> Province</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/address/country.blade.php ENDPATH**/ ?>