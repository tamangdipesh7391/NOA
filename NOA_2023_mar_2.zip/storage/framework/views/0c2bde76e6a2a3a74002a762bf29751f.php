
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-4 mb-3">
                            <h1>
                                <i class="bi bi-eye-fill"></i>
                                Manage Gallery
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-12">
                                <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <form action="<?php echo e(route('admin-gallery.store')); ?>" method="post"
                                          enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <label for="title">Title <a href=""
                                                                                style="color: red;">*<?php echo e($errors->first('title')); ?></a></label>
                                                    <input type="text" name="title" id="title"
                                                           value="<?php echo e(old('title')); ?>"
                                                           class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="photos">Photos:
                                                        <span>Upload multiple photos</span>
                                                        <a href=""
                                                           style="color: red;"><?php echo e($errors->first('photos')); ?></a></label>
                                                    <input type="file" name="photos[]" id="photos"
                                                           multiple class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <button class="btn btn-success" style="margin-top: 18px;">
                                                        <i class="fa fa-plus"></i> Create
                                                        Gallery
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-md-12 mt-5">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>S.no</th>
                                            <th>Title</th>
                                            <th>Status</th>
                                            <th>Image</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $galleryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($gallery->title); ?></td>
                                                <td>
                                                    <?php if($gallery->status==1): ?>
                                                        <button name="enable" class="btn-xs btn-success">
                                                            <i class="fa fa-check"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <button name="disable" class="btn-xs btn-danger">
                                                            <i class="fa fa-times"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="">Total <?php echo e($gallery->totalGalleryImage()); ?>

                                                        Images: </a>
                                                </td>

                                                <td>
                                                    <form
                                                        action="<?php echo e(route('admin-gallery.destroy',$gallery->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <a href="<?php echo e(route('admin-gallery.show',$gallery->id)); ?>"
                                                           class="btn btn-info">
                                                            <i class="fa fa-eye"></i> Show</a>
                                                        <a href="<?php echo e(route('admin-gallery.edit',$gallery->id)); ?>"
                                                           class="btn btn-primary" title="edit">
                                                            <i class="fa fa-edit"></i> Edit</a>
                                                        <button class="btn btn-danger" title="Delete">
                                                            <i class="fa fa-trash"></i> Delete
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/gallery/index.blade.php ENDPATH**/ ?>