<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-4 mb-2">
                            <h1>
                                Conference List
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-12">
                                <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="row">
                                <table id="datatable" class="table table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th>S.no</th>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $conferenceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$conference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td>
                                                <?php echo e($conference->title); ?>

                                                <hr>
                                                <a href="<?php echo e(route('admin-conference-participation',$conference->id)); ?>">Participation: <?php echo e($conference->totalConference()); ?></a>
                                            </td>
                                            <td>
                                                <?php if($conference->status==1): ?>
                                                    <button name="enable" class="btn-xs btn-success">
                                                        <i class="fa fa-check"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <button name="disable" class="btn-xs btn-danger">
                                                        <i class="fa fa-times"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($conference->image): ?>
                                                    <img src="<?php echo e(url($conference->image)); ?>"
                                                         alt="" width="40">
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <form action="<?php echo e(route('admin-conference.destroy',$conference->id)); ?>"
                                                      method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <a href="<?php echo e(route('admin-conference.show',$conference->id)); ?>"
                                                       class="btn btn-info"><i
                                                            class="fa fa-eye"></i></a>
                                                    <a href="<?php echo e(route('admin-conference.edit',$conference->id)); ?>"
                                                       class="btn btn-primary" title="edit">
                                                        <i class="fa fa-edit"></i></a>

                                                    <button class="btn-sm btn-danger" title="Delete">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/conference/index.blade.php ENDPATH**/ ?>