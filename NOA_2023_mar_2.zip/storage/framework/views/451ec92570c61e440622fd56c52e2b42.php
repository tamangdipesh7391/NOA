<?php
$eventsData = CommonHelper::getEventsData();
$bannerData = CommonHelper::getBannerData();
$partnersData = CommonHelper::getPartnersData();
$welContent = CommonHelper::welcomeContent();

?>


<?php $__env->startSection('content'); ?>

    <!--==============Slider Section=================-->
    <div style="width: 100%;">
        <div id="carouselExampleCaptions" class="carousel" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $bannerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key==0): ?>
                        <div class="carousel-item active">
                            <?php if($banner->image): ?>
                                <img src="<?php echo e(url($banner->image)); ?>" class="w-100" style="height: 460px" alt="...">
                            <?php endif; ?>
                            <div class="carousel-caption d-none d-md-block">
                                <h5><?php echo e($banner->title); ?></h5>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="carousel-item">
                            <?php if($banner->image): ?>
                                <img src="<?php echo e(url($banner->image)); ?>" class="w-100" style="height: 460px" alt="...">
                            <?php endif; ?>
                            <div class="carousel-caption d-none d-md-block">
                                <h5><?php echo e($banner->title); ?></h5>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!--==============End Slider Section=================-->

    <div class="main-section">
        <div class="container mt-5">
            <div class="row">
                    <?php $__currentLoopData = $welContent->getContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="home-box-content">
                                <h3> <?php echo e($content->title); ?></h3>
                                <p>
                                    <?php echo $content->description; ?>

                                </p>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <div class="row">
                <!--<div class="col-md-12 mb-3">
                    <h1><?php echo e($welContent->title); ?></h1>
                </div>-->
                <div class="col-md-12 mb-3">
                    <p>
                        <?php echo $welContent->description; ?>

                    </p>

                </div>
                

            </div>

        </div>
    </div>

    
    

    <!--==============End Project  Section=================-->

    <!--==============News Slider Section =================-->
    <?php echo $__env->make('frontend.components.news-slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--==============End News Slider Section =================-->

    <!--events start-->
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-5 mb-4">
                <h1>Recent Events</h1>
            </div>
            <?php $__currentLoopData = $eventsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-3">
                    <a href="<?php echo e(route('events',$event->slug)); ?>">
                    <figure class="snip1253 snipnew">
                        <div class="image">
                            <?php if($event->image): ?>
                                <img
                                    src="<?php echo e(url($event->image)); ?>"
                                    alt="<?php echo e($event->title); ?>"/>
                            <?php endif; ?>
                        </div>
                        <figcaption>
                            <div class="date"><span class="day">01</span><span class="month">Jan</span></div>
                            <h3><?php echo e($event->title); ?></h3>
                            <p>
                                <?php echo $event->getLimitDescription(); ?>

                            </p>
                        </figcaption>
                        <footer>
                            <div class="views">Read more</div>
                        </footer>
                        
                    </figure>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<!--event ends-->

    <div class="container mb-5 mt-5">
        <h2 class="mb-5">Our Partners</h2>
        <div class="container">
            <section class="customer-logos slider">
                <?php $__currentLoopData = $partnersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide"><a href="#"><img src="<?php echo e(url($partner->image)); ?>"></a></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/home/home.blade.php ENDPATH**/ ?>