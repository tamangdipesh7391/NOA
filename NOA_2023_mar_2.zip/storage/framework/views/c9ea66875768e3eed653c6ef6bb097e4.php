<?php
$menuData = CommonHelper::getAllMenu();
?>

<?php $__env->startSection('menu'); ?>
    <div class="stellarnav">
        <ul>
            <?php $__currentLoopData = $menuData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($menu->slug=='home'): ?>
                    <li><a href="/"><i class="fa fa-home"></i> </a></li>
                <?php elseif($menu->slug=='about-us'): ?>
                    <li><a href="#"><?php echo e($menu->name); ?></a>
                        <ul>
                            <?php $__currentLoopData = $menu->subAboutMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('about-us').'/'.$subMenu->slug); ?>"><?php echo e($subMenu->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php elseif($menu->slug=='activities'): ?>
                    <li><a href="<?php echo e(url('activities')); ?>"><?php echo e($menu->name); ?></a></li>
                <?php elseif($menu->slug=='our-projects'): ?>
                    <li><a href="<?php echo e(url('our-projects')); ?>"><?php echo e($menu->name); ?></a></li>
                <?php elseif($menu->slug=='awards'): ?>
                    <li><a href="<?php echo e(url('awards')); ?>"><?php echo e($menu->name); ?></a></li>
                <?php elseif($menu->slug=='conference'): ?>
                    <li><a href="<?php echo e(url('conference')); ?>"><?php echo e($menu->name); ?></a></li>

                <?php elseif($menu->slug=='publication'): ?>
                    <li><a href="<?php echo e(url('publication')); ?>"><?php echo e($menu->name); ?></a>
                    </li>
                <?php elseif($menu->slug=='financial-reports-funding'): ?>
                    <li><a href="<?php echo e(url('financial-reports-funding')); ?>"><?php echo e($menu->name); ?></a>
                    </li>
                 <?php elseif($menu->slug=='events'): ?>
                    <li><a href="<?php echo e(url('events')); ?>"><?php echo e($menu->name); ?></a></li>
                <?php elseif($menu->slug=='gallery'): ?>
                    <li><a href="<?php echo e(url('gallery')); ?>"><?php echo e($menu->name); ?></a></li>
                <?php elseif($menu->slug=='video'): ?>
                    <li><a href="<?php echo e(url('video')); ?>"><?php echo e($menu->name); ?></a></li>
                <?php elseif($menu->slug=='rewards'): ?>
                    <li><a href="<?php echo e(url('rewards')); ?>"><?php echo e($menu->name); ?></a></li>
                
                <?php elseif($menu->slug=='travel-grant'): ?>
                    <li><a href="<?php echo e(url('travel-grant')); ?>"><?php echo e($menu->name); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/layouts/menu.blade.php ENDPATH**/ ?>