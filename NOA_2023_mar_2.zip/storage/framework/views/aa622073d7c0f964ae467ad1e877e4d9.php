
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h1>
                                <i class="bi bi-bag-plus-fill"></i>
                                Add Menu

                                <a href="<?php echo e(route('admin-menu.index')); ?>" class="btn btn-primary">
                                    <i class="bi bi-arrow-right-circle-fill"></i> Menu List
                                </a>
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <form action="<?php echo e(route('admin-menu.store')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group mb-2 mb-2">
                                    <label for="title">Name <a href=""
                                                               style="color: red;text-decoration: none;">*<?php echo e($errors->first('name')); ?></a></label>
                                    <input type="text" name="name" id="title" value="<?php echo e(old('name')); ?>"
                                           class="form-control">
                                </div>
                                <div class="form-group mb-2 mb-2">
                                    <label for="slug">Slug <a href=""
                                                              style="color: red;"><?php echo e($errors->first('slug')); ?></a></label>
                                    <input type="text" name="slug" id="slug"
                                           value="<?php echo e(old('slug')); ?>" class="form-control">
                                </div>
                                <div class="form-group mb-2 mb-2">
                                    <label for="icon">Icon <a href=""
                                                              style="color: red;"><?php echo e($errors->first('icon')); ?></a></label>
                                    <input type="text" name="icon" id="icon"
                                           value="<?php echo e(old('icon')); ?>" class="form-control">
                                </div>
                                <div class="form-group mb-2 mb-2">
                                    <label for="url">Url <a href=""
                                                              style="color: red;"><?php echo e($errors->first('url')); ?></a></label>
                                    <input type="text" name="url" id="url"
                                           value="<?php echo e(old('url')); ?>" class="form-control">
                                </div>


                                <div class="form-group mb-2 mb-2">
                                    <button type="submit" class="btn btn-success">
                                        <i class="bi bi-bag-plus-fill"></i> Add Menu
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/menu/create.blade.php ENDPATH**/ ?>