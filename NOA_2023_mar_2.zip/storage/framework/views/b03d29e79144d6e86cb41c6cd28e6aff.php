
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-4 mb-3">
                            <h1>
                                <i class="bi bi-eye-fill"></i>
                                Gallery List
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h1><?php echo e($galleryData->title); ?></h1>
                            <hr>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <?php $__currentLoopData = $galleryImageData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <img style="width: 100%; display: block;"
                                             src="<?php echo e(url($image->image_name)); ?>" alt="image">

                                        <div class="mt-2">

                                            <a class="btn-sm btn-primary"
                                               href="<?php echo e(route('edit-galley-image',$image->id)); ?>"><i
                                                    class="fa fa-pencil"></i> Update</a>
                                            <a class="btn-sm btn-danger"
                                               href="<?php echo e(route('delete-galley-image',$image->id)); ?>"><i
                                                    class="fa fa-times"></i> Delete</a>
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/gallery/show.blade.php ENDPATH**/ ?>