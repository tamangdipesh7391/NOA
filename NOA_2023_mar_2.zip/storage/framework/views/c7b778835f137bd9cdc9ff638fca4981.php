
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h1><i class="bi bi-eye-fill"></i> Menu List
                                <a href="<?php echo e(route('admin-menu.create')); ?>">Add Menu</a>
                            </h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-md-12">
                            <form action="">
                                <div class="row">
                                    <div class="col-md-10" style="padding-right: 2px;">
                                        <input type="text" name="search" placeholder="Enter any keywords"
                                               required class="form-control">
                                    </div>
                                    <div class="col-md-2" style="padding-left: 0;">
                                        <button class="btn btn-success">
                                            <i class="bi bi-search"></i> Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <hr>
                        </div>

                        <div class="col-md-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>S.no</th>
                                    <th>Name</th>
                                    <th>Slug</th>
                                    <th>Icons</th>
                                    <th>Url</th>
                                    <th>Order</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $key1 = 1;
                                if (isset($_GET['page']) && $_GET['page'] != '') {
                                    $key1 = 5 * ($_GET['page'] - 1) + 1;
                                } ?>
                                <?php $__currentLoopData = $menuData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key1++); ?></td>
                                        <td>
                                            <?php echo e($page->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($page->slug); ?>

                                        </td>
                                        <td>
                                            <?php echo e($page->icons); ?>

                                        </td>
                                        <td>
                                            <?php echo e($page->url); ?>

                                        </td>
                                        <td>
                                            <?php echo e($page->order); ?>

                                        </td>

                                        <td>
                                            <form action="<?php echo e(route('admin-menu.destroy',$page->id)); ?>"
                                                  method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <a href="<?php echo e(route('admin-menu.edit',$page->id)); ?>"
                                                   class="btn btn-primary" title="edit">
                                                    <i class="bi bi-pencil-square"></i></a>

                                                <button class="btn btn-danger" title="Delete">
                                                    <i class="bi bi-trash-fill"></i>
                                                </button>

                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            <?php echo e($menuData->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/menu/index.blade.php ENDPATH**/ ?>