<?php $__env->startSection('footer'); ?>
    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>Tech Rastra</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a href="https://techrastra.com/">Tech Rastra</a>
        </div>
    </footer><!-- End Footer -->
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>
    <!-- Vendor JS Files -->
    <script src="<?php echo e(url('backend-assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend-assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(url('backend-assets/ckeditor/ckeditor.js')); ?>"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(url('backend-assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(url('backend-assets/custom/custom.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script>
        let ckeditorUploadUrl = "<?php echo e(route('ckeditor-image-upload', ['_token' => csrf_token() ])); ?>";
    </script>
    </body>
    </html>
<?php $__env->stopSection(); ?>
<?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/layouts/footer.blade.php ENDPATH**/ ?>