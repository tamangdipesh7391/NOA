
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <h1>
                                <i class="bi bi-bag-plus-fill"></i>
                                Manage Partners
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <form action="<?php echo e(route('admin-partners.store')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label for="link">Links</label>
                                    <input type="text" name="link" id="link"
                                           class="form-control">
                                </div>
                                <div class="form-group mb-3">
                                    <label for="status">Status</label>
                                    <select name="status" id="status" class="form-control">
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="image">Logo</label>
                                    <input type="file" name="image" class="form-control">
                                </div>
                                <div class="form-group mb-3">
                                    <button class="btn btn-success">
                                        <i class="fa fa-plus"></i> Add Partner
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-12 mt-5">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>S.n</th>
                                    <th>Link</th>
                                    <th>Status</th>
                                    <th>Order</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $partnersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($partner->link); ?></td>
                                        <td><?php echo e($partner->status); ?></td>
                                        <td><?php echo e($partner->order); ?></td>
                                        <td>
                                            <img src="<?php echo e(url($partner->image)); ?>" width="50" alt="">
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('admin-partners.destroy',$partner->id)); ?>"
                                                  method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href="<?php echo e(route('admin-partners.edit',$partner->id)); ?>"
                                                   class="btn btn-primary">
                                                    <i class="fa fa-pencil-square"></i> Edit</a>
                                                <button class="btn btn-danger">
                                                    <i class="fa fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/partners/index.blade.php ENDPATH**/ ?>