<?php
$eventsData = CommonHelper::getAllEventsData();

?>


<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12 mb-5">
                <h1>Events</h1>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $eventsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $events): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-5">
                    <div class="card">
                        <?php if($events->image): ?>
                            <img src="<?php echo e(url($events->image)); ?>" class="card-img-top" alt="...">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($events->title); ?></h5>
                            <p class="card-text">
                                <?php echo $events->getLimitDescription(); ?>

                            </p>
                            <a href="<?php echo e(route('events',$events->slug)); ?>" class="btn btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/events/index.blade.php ENDPATH**/ ?>