
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h1>
                                <i class="bi bi-bag-plus-fill"></i>
                                Update Menu

                                <a href="<?php echo e(route('admin-menu.index')); ?>" class="btn btn-primary">
                                    <i class="bi bi-arrow-right-circle-fill"></i> Menu List
                                </a>
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-md-12">
                            <form action="<?php echo e(route('admin-menu.update',$menuData->id)); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <div class="form-group mb-3">
                                    <label for="title">Name <a href=""
                                                               style="color: red;text-decoration: none;">*<?php echo e($errors->first('name')); ?></a></label>
                                    <input type="text" name="name" id="title" value="<?php echo e($menuData->name); ?>"
                                           class="form-control">
                                </div>
                                <div class="form-group mb-3">
                                    <label for="slug">Slug <a href=""
                                                              style="color: red;"><?php echo e($errors->first('slug')); ?></a></label>
                                    <input type="text" name="slug" id="slug"
                                           value="<?php echo e($menuData->slug); ?>" class="form-control">
                                </div>
                                <div class="form-group mb-3">
                                    <label for="icon">Icon <a href=""
                                                              style="color: red;"><?php echo e($errors->first('icon')); ?></a></label>
                                    <input type="text" name="icon" id="icon"
                                           value="<?php echo e($menuData->icon); ?>" class="form-control">
                                </div>
                                <div class="form-group mb-3">
                                    <label for="url">Url <a href=""
                                                            style="color: red;"><?php echo e($errors->first('url')); ?></a></label>
                                    <input type="text" name="url" id="url"
                                           value="<?php echo e($menuData->url); ?>" class="form-control">
                                </div>
                                <div class="form-group mb-3">
                                    <label for="order">Order <a href=""
                                                            style="color: red;"><?php echo e($errors->first('order')); ?></a></label>
                                    <input type="number" name="order" id="order"
                                           value="<?php echo e($menuData->order); ?>" class="form-control">
                                </div>


                                <div class="form-group mb-3">
                                    <button type="submit" class="btn btn-success">
                                        <i class="bi bi-bag-plus-fill"></i> Update Menu
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/menu/update.blade.php ENDPATH**/ ?>