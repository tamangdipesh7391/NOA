
<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-12">
                <h1>Create New Account</h1>
                <?php echo e($user ?? ''); ?>

            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <h3 class="card-title mb-4">
                                    <i class="fa fa-users"></i> Member Details
                                </h3>
                            </div>
                        </div>
                        <div class="row">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="col-md-8">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mb-3">
                                            <label for="name">Name:
                                                <a style="color: red;text-decoration: none;">
                                                    <?php if($errors->has('name')): ?>
                                                        <?php echo e($errors->first('name')); ?>

                                                    <?php endif; ?>
                                                </a>
                                            </label>
                                            <input type="text"
                                                   value="<?php echo e($user->name ?? old('name')); ?>"
                                                   id="name"
                                                   name="name" class="form-control">
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="email">Email:
                                                        <a style="color: red;text-decoration: none;">
                                                            <?php if($errors->has('email')): ?>
                                                                <?php echo e($errors->first('email')); ?>

                                                            <?php endif; ?>
                                                        </a>
                                                    </label>
                                                    <input type="text" value="<?php echo e($user->email ?? old('email')); ?>"
                                                           id="email"
                                                           name="email" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-2">
                                                    <label for="gender">Gender:<a
                                                            style="color: red;"><?php echo e($errors->first('gender')); ?></a>
                                                    </label>
                                                    <select name="gender" id="gender"
                                                            class="form-control">
                                                        <option value="" readonly>---Select Gender---</option>
                                                        <option value="male" <?php echo e(old('gender') =='male' ? 'selected' :''); ?>>Male</option>
                                                        <option value="female" <?php echo e(old('gender') =='female' ? 'selected' :''); ?>>Female</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="phone">Phone:
                                                        <a style="color: red;text-decoration: none;">
                                                            <?php if($errors->has('phone')): ?>
                                                                <?php echo e($errors->first('phone')); ?>

                                                            <?php endif; ?>
                                                        </a>
                                                    </label>
                                                    <input type="text" value="<?php echo e($user->phone ?? old('phone')); ?>"
                                                           id="phone"
                                                           name="phone" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="date_of_birth">Date of Brith:
                                                        <a style="color: red;text-decoration: none;">
                                                            <?php if($errors->has('date_of_birth')): ?>
                                                                <?php echo e($errors->first('date_of_birth')); ?>

                                                            <?php endif; ?>
                                                        </a>
                                                    </label>
                                                    <input type="date"
                                                           value="<?php echo e($user->date_of_birth ?? old('date_of_birth')); ?>"
                                                           id="date_of_birth"
                                                           name="date_of_birth" class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="password">Password:
                                                <a style="color: red;text-decoration: none;">
                                                    <?php if($errors->has('password')): ?>
                                                        <?php echo e($errors->first('password')); ?>

                                                    <?php endif; ?>
                                                </a>
                                            </label>
                                            <input type="password" value="<?php echo e($user->password ?? old('password')); ?>"
                                                   id="password"
                                                   name="password" class="form-control">
                                        </div>


                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-3">
                                            <label for="member_type">Membership type:
                                                <a style="color: red;text-decoration: none;">*
                                                    <?php echo e($errors->first('membership_type_id')); ?></a>
                                            </label>
                                            <select name="membership_type_id" id="member_type" class="form-control">
                                                <option value="" selected readonly>Select member type</option>
                                                <?php $__currentLoopData = $memberTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($type->id); ?>"
                                                        <?php echo e($user->membership_type_id?? old('member_type_id')==$type->id ? 'selected':''); ?>

                                                    ><?php echo e($type->type); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <?php $__currentLoopData = $memberTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <h3><?php echo e($type->type); ?>: <?php echo e($type->price); ?></h3>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <button class="btn btn-success">
                                            Next
                                        </button>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/register/register-step-one.blade.php ENDPATH**/ ?>