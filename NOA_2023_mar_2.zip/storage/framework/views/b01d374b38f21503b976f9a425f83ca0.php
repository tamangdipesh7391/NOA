
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <!--<div class="row">
            <div class="col-md-12 mb-5">
                <h1>Activities Details</h1>
            </div>
        </div>-->
        <div class="row">
            <div class="col-md-8">
                <h1><?php echo e($eventsData->title); ?></h1>
                <?php if($eventsData->image): ?>
                    <img src="<?php echo e(url($eventsData->image)); ?>" class="card-img-top" alt="...">
                <?php endif; ?>
                <p>
                    <?php echo $eventsData->description; ?>

                </p>

            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Related Events</h3>
                    </div>
                    <div class="col-md-12">

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/events/details.blade.php ENDPATH**/ ?>