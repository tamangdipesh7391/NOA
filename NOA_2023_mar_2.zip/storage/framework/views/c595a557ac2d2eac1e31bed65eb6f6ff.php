
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-4 mb-2">
                            <h1>
                                <i class="bi bi-eye-fill"></i>
                                Publication Details
                                <a href="<?php echo e(route('admin-publication.index')); ?>"
                                   class="btn btn-success">
                                    <i class="bi bi-arrow-right-circle-fill"></i> Goto Index Page</a>
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <h2><a href="">Title: <?php echo e($publicationData->title); ?></a></h2>
                            <h2><a href="">Slug: <?php echo e($publicationData->slug); ?></a></h2>
                            <p>Meta Description:
                                <?php echo $publicationData->meta_description; ?>

                            </p>
                            <p> Description:
                                <?php echo $publicationData->description; ?>

                            </p>

                        </div>
                        <div class="col-md-4">
                            <?php if($publicationData->image): ?>
                                <img src="<?php echo e(url($publicationData->image)); ?>"
                                     class="img-fluid" alt="">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-12 mb-4 mt-3">
                            <hr>
                            <a href="<?php echo e(route('admin-publication.index')); ?>"
                               class="btn btn-success">
                                <i class="fa fa-hand-o-left"></i> Back</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h1>Files:</h1>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <?php $__currentLoopData = $publicationData->getFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3" style="height: 150px;margin: 20px;padding: 20px;
                                        font-size: 20px;">
                                        <?php if($file->file): ?>
                                            <a href="<?php echo e(url($file->file)); ?>" target="_blank">
                                                <?php echo e($file->name); ?>

                                                <hr>
                                                Views
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/publication/show.blade.php ENDPATH**/ ?>