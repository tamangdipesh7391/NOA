
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-4 mb-2">
                            <h1>
                                <i class="bi bi-pencil-square"></i>
                                Update Publication
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <form action="<?php echo e(route('admin-publication.update',$publicationData->id)); ?>"
                                  method="post"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group mb-2">
                                            <label for="title">Title: <a href=""
                                                                         style="color: red;"><?php echo e($errors->first('title')); ?></a></label>
                                            <input type="text" name="title" id="title"
                                                   value="<?php echo e($publicationData->title); ?>"
                                                   class="form-control">

                                        </div>
                                        <div class="form-group mb-2">
                                            <label for="slug">Slug <a href=""
                                                                      style="color: red;"><?php echo e($errors->first('slug')); ?></a></label>
                                            <input type="text" name="slug" id="slug"
                                                   value="<?php echo e($publicationData->slug); ?>"
                                                   class="form-control">

                                        </div>
                                        <div class="form-group mb-2">
                                            <label for="meta_title">Meta Title</label>
                                            <textarea name="meta_title" class="form-control"
                                                      id="meta_title"><?php echo e($publicationData->meta_title); ?></textarea>
                                        </div>
                                        <div class="form-group mb-2">
                                            <label for="meta_description">Meta Description</label>
                                            <textarea name="meta_description" id="meta_description"
                                                      style="resize: none;" class="form-control"
                                                      rows="4"> <?php echo e($publicationData->meta_description); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label for="type"> Type:
                                                <a style="color: red;"><?php echo e($errors->first('type')); ?></a>
                                            </label>
                                            <select name="type" id="status"
                                                    class="form-control">
                                                <option
                                                    value="normal" <?php echo e($publicationData->type == 'normal' ? 'selected' : ''); ?>>
                                                    Normal
                                                </option>
                                                <option
                                                    value="advanced" <?php echo e($publicationData->type  == 'advanced' ? 'selected' : ''); ?>>
                                                    Advanced
                                                </option>
                                            </select>
                                        </div>
                                        <div class="form-group mb-2">
                                            <label for="status"> Status:
                                                <a style="color: red;"><?php echo e($errors->first('status')); ?></a>
                                            </label>
                                            <select name="status" id="status"
                                                    class="form-control">
                                                <option
                                                    value="1" <?php echo e($publicationData->status == '1' ? 'selected' : ''); ?>>
                                                    Public
                                                </option>
                                                <option
                                                    value="0" <?php echo e($publicationData->status == '0' ? 'selected' : ''); ?>>
                                                    Draft
                                                </option>

                                            </select>
                                        </div>
                                        <div class="form-group mb-2 mb-2">
                                            <label for="menu"> Menu:
                                                <a style="color: red;"><?php echo e($errors->first('menu')); ?></a>
                                            </label>
                                            <select name="menu_id" id="menu"
                                                    class="form-control">
                                                <option value="<?php echo e($publicationData->menu->id ?? ""); ?>">
                                                    <?php echo e($publicationData->menu->name ?? ""); ?>

                                                </option>
                                                <?php $__currentLoopData = $menuData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($menu->id); ?>" <?php echo e(old('menu_id') == $menu->id ? 'selected' : ''); ?>>
                                                        <?php echo e($menu->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                        <div class="form-group mb-2">
                                            <?php if($publicationData->image): ?>
                                                <img src="<?php echo e(url($publicationData->image)); ?>"
                                                     id="image_show" alt="<?php echo e($publicationData->title); ?>"
                                                     class="img-fluid" style="margin-top: 23px;height: 100px;">
                                            <?php else: ?>
                                                <img src="<?php echo e(url('icons/ui.png')); ?>"
                                                     class="img-fluid" id="image_show" alt="<?php echo e($publicationData->title); ?>"
                                                     style="margin-top: 23px;height: 200px;">
                                            <?php endif; ?>

                                            <div class="choose_file">
                                                <span><i class="fa fa-upload"></i> Change Image</span>
                                                <input name="image" type="file" id="change_image">
                                            </div>
                                            <a style="color: red;"><?php echo e($errors->first('image')); ?></a>
                                        </div>
                                    </div>

                                </div>


                                <div class="form-group mb-2">
                                    <label for="summary">Intro text
                                        <a style="color: red;"><?php echo e($errors->first('intro_text')); ?></a>
                                    </label>
                                    <textarea name="intro_text" id="summary"
                                              class="form-control"
                                              rows="4"><?php echo e($publicationData->intro_text); ?></textarea>
                                </div>

                                <div class="form-group mb-2">
                                    <label for="description_id">Details</label>
                                    <textarea name="description" id="description_id"
                                              class="form-control">
                                                    <?php echo e($publicationData->description); ?>

                                                </textarea>
                                </div>

                                <div class="form-group mb-2">
                                    <button class="btn btn-success">
                                        <i class="bi bi-pencil-square"></i> Update Publication
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            CKEDITOR.replace('summary', {
                filebrowserUploadUrl: ckeditorUploadUrl,
                filebrowserUploadMethod: 'form'
            });
            CKEDITOR.replace('description', {
                filebrowserUploadUrl: ckeditorUploadUrl,
                filebrowserUploadMethod: 'form'
            });

        });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/publication/update.blade.php ENDPATH**/ ?>