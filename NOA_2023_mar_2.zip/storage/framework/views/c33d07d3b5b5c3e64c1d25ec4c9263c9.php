<?php
$is_download = true;
?>

    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            top: 0;
        }

        .container {
            width: 70%;
            margin: auto;
        }

        .title-section {
            width: 100%;
            background: green;
            height: 30px;
            color: green;
        }

        .footer-section {
            width: 100%;
            background: green;
            height: 30px;
        }

        .body-section {
            width: 100%;
            min-height: 300px;
        }

        .logo-section {
            float: left;
            margin: 20px;
        }
        .body-text-section-box{
            color: green;
        }
        .body-text-section-box h1{
            font-size: 30px;
            margin-bottom: 0;
            padding: 0;
        }

        .photo-footer-section-box {
            width: 100%;

        }

        .photo-footer-section-box h1 {
            font-size: 18px;
            margin-left: 30px;
        }

        .photo-box-section {
            width: 100%;
        }
        .photo-content{
            text-align: center;
        }
        .photo-name-section{
            text-align: center;
        }

        .backend-section {
            width: 100%;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="frontend">
        <div class="title-section">

        </div>
        <div class="body-section">
            <div class="logo-section">
                <?php if($is_download): ?>
                    <img src="<?php echo e(public_path('icons/logo.png')); ?>" alt="">
                <?php else: ?>
                    <img src="<?php echo e(url('icons/logo.png')); ?>" alt="">
                <?php endif; ?>

            </div>
            <div class="body-text-section-box">
                <h1>Nepalese Association of Optometrists</h1>
                <h3>Thrive for excellence in vision care</h3>
            </div>
            <div class="photo-box-section">
                <div class="photo-title">
                    <h1>Member Id Card</h1>
                </div>
                <div class="photo-content">
                    <?php if($is_download): ?>

                    <?php else: ?>

                    <?php endif; ?>
                </div>
                <div class="photo-name-section">
                    <h1><?php echo e($userData->name); ?></h1>
                </div>
                <div class="photo-footer-section-box">
                    <h1> NAO Membership No: 0022<?php echo e($userData->id); ?></h1>
                    <h1>Membership Type: <?php echo e($userData->memberType->type ?? ''); ?> </h1>
                    <h1>Expiry Date: <?php echo e($userData->isExpired()); ?></h1>
                    <h1>Citizenship No: <?php echo e($userData->userDocuments->citizenship_no ?? ''); ?></h1>
                    <h1>Phone No: <?php echo e($userData->phone); ?> </h1>
                    <h1>Address: <?php echo e($userData->userAddress->tDistrict->district_name ?? ''); ?> </h1>
                </div>
            </div>


        </div>
        <div class="footer-section">

        </div>
    </div>


    <div class="backend-section">
        <div class="title-section"></div>
        <div class="title">
            <h1>Note:</h1>
        </div>
        <div class="top-content">
            <p>
                This card is property of the Nepalese Association of Optometrists (NAO)
                It must be carried at all times and presented to NAO officials upon request.
                This card holder is responsible for use & misuse of this card.
            </p>
        </div>
        <div class="footer-content">
            <p>
                If this card is found please return to following address
            </p>
        </div>
        <div class="footer-section"></div>
    </div>

</div>
</body>
</html>
<?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/members/id-card.blade.php ENDPATH**/ ?>