
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mt-3 mb-2">
                            <h1>
                                <i class="bi bi-eye-fill"></i>  Events List
                            </h1>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-12">
                                <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="col-md-12">
                                <table class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th>S.no</th>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $eventsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$events): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($events->title); ?>   </td>
                                            <td>
                                                <?php if($events->status==1): ?>
                                                    <button name="enable" class="btn-xs btn-success">
                                                        <i class="fa fa-check"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <button name="disable" class="btn-xs btn-danger">
                                                        <i class="fa fa-times"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($events->image): ?>
                                                    <img src="<?php echo e(url($events->image)); ?>"
                                                         alt="" width="40">
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <form action="<?php echo e(route('admin-events.destroy',$events->id)); ?>"
                                                      method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <a href="<?php echo e(route('admin-events.show',$events->id)); ?>"
                                                       class="btn btn-info"> <i class="bi bi-eye-fill"></i></a>
                                                    <a href="<?php echo e(route('admin-events.edit',$events->id)); ?>"
                                                       class="btn btn-primary" title="edit">
                                                        <i class="bi bi-pencil-square"></i></a>

                                                    <button class="btn-sm btn-danger" title="Delete">
                                                        <i class="bi bi-trash-fill"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/events/index.blade.php ENDPATH**/ ?>