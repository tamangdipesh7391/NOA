<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <!--<div class="row">
            <div class="col-md-12 mb-5">
                <h1>News Details</h1>
            </div>
        </div>-->
        <div class="row">
            <div class="col-md-8">
                <h1><?php echo e($newsData->title); ?></h1>
                <?php if($newsData->image): ?>
                    <img src="<?php echo e(url($newsData->image)); ?>" class="card-img-top" alt="...">
                <?php endif; ?>
                <p>
                    <?php echo $newsData->description; ?>

                </p>

            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Related Eye Health Topics</h3>
                    </div>
                    <div class="col-md-12">
                        <ul>
                            <?php $__currentLoopData = $relatedNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rNews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('news',$rNews->slug)); ?>"><?php echo e($rNews->title); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/news/details.blade.php ENDPATH**/ ?>