
<div class="container">
    <!-- generate function from simple-qr code package -->

    <?php echo e(QrCode::generate('https://www.optometrynepal.org/')); ?>

</div>


<?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/layouts/qr-code.blade.php ENDPATH**/ ?>