<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12 mb-5">
                <h1>Rewards</h1>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $rewardsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $awards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-5">
                    <div class="card">
                        <?php if($awards->image): ?>
                            <img src="<?php echo e(url($awards->image)); ?>" class="card-img-top" alt="...">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($awards->title); ?></h5>
                            <p class="card-text">
                                <?php echo $awards->getLimitDescription(); ?>

                            </p>
                            <a href="<?php echo e(route('rewards',$awards->slug)); ?>" class="btn btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/rewards/index.blade.php ENDPATH**/ ?>