
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-12 mt-4 mb-2">
                            <h1>
                                <i class="fa fa-eye"></i>
                                Show Banner
                                <a href="<?php echo e(route('admin-banner.create')); ?>"
                                   class="btn btn-success pull-right">
                                    <i class="fa fa-plus"></i> Add New</a>

                            </h1>
                            <hr>
                        </div>
                        <div class="col-md-12">
                            <form action="">
                                <div class="row">
                                    <div class="col-md-10" style="padding-right: 2px;">
                                        <input type="text" name="search" placeholder="Enter any keywords"
                                               class="form-control">
                                    </div>
                                    <div class="col-md-2" style="padding-left: 0;">
                                        <button class="btn btn-success">
                                            <i class="bi bi-search"></i> Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-md-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>S.no</th>
                                    <th>Title</th>
                                    <th>Status</th>
                                    <th>Order</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <?php if($bannerData->count()>0): ?>
                                    <tbody>

                                    <?php $__currentLoopData = $bannerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin-banner.show',$banner->id)); ?>">
                                                    <?php echo e($banner->title); ?>

                                                </a>
                                            </td>
                                            <td>
                                                <?php if($banner->status==1): ?>
                                                    <button name="enable" class="btn-xs btn-success">
                                                        <i class="bi bi-check-circle-fill"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <button name="disable" class="btn-xs btn-danger">
                                                        <i class="bi bi-x-circle"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($banner->order); ?>

                                            </td>
                                            <td>
                                                <?php if($banner->image): ?>
                                                    <img src="<?php echo e(url($banner->image)); ?>"
                                                         alt="" width="40">
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <form action="<?php echo e(route('admin-banner.destroy',$banner->id)); ?>"
                                                      method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <a href="<?php echo e(route('admin-banner.show',$banner->id)); ?>"
                                                       title="Details" class="btn btn-info"> <i
                                                            class="bi bi-eye-fill"></i></a>
                                                    <a href="<?php echo e(route('admin-banner.edit',$banner->id)); ?>"
                                                       class="btn btn-primary" title="Update">
                                                        <i class="bi bi-pencil-square"></i></a>

                                                    <button class="btn btn-danger" title="Delete">
                                                        <i class="bi bi-trash-fill"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center">
                                                <h3 class="mt-2">No Data Found</h3>
                                                <a href="<?php echo e(route('admin-banner.index')); ?>">Goto Index</a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                            </table>
                        </div>

                        <div class="col-md-12">
                            <?php echo e($bannerData->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('backend.master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/backend/pages/banner/index.blade.php ENDPATH**/ ?>