
<?php $__env->startSection('content'); ?>
    <div class="container mb-5 mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1 class="is-size-1">Register New Account</h1>
            </div>
        </div>
        <div class="row">
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Permanent address</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="permanent_country">Country:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('permanent_country')); ?></a>
                                            </label>
                                            <select name="permanent_country" id="permanent_country"
                                                    class="form-control">
                                                <option value="" selected readonly>Select Country</option>
                                                <?php $__currentLoopData = $countryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($country->id); ?>"
                                                        <?php echo e($addressData->permanent_country ?? old('permanent_country')==$country->id ? 'selected':''); ?>>
                                                        <?php echo e($country->country_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="permanent_province">Province:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('permanent_province')); ?></a>

                                            </label>
                                            <select name="permanent_province" id="permanent_province"
                                                    class="form-control">
                                                <option value="" selected readonly>Select Province

                                                </option>
                                                <?php $__currentLoopData = $provinceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($province->id); ?>"
                                                        <?php echo e($province->id==$addressData->permanent_province ?? old('permanent_province')==$province->id ? 'selected':''); ?>>
                                                        <?php echo e($province->province_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="permanent_district">District:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('permanent_district')); ?></a>
                                            </label>
                                            <select name="permanent_district" id="permanent_district"
                                                    class="form-control">
                                                <option value="" selected readonly>Select District</option>
                                                <?php $__currentLoopData = $districtData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($district->id); ?>"
                                                        <?php echo e($district->id==$addressData->permanent_district ?? old('permanent_district')==$district->id ? 'selected':''); ?>>
                                                        <?php echo e($district->district_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-2">
                                            <label for="permanent_municipality">Municipality:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('permanent_municipality')); ?></a>
                                            </label>
                                            <select name="permanent_municipality" id="permanent_municipality"
                                                    class="form-control">
                                                <option value="" selected readonly>Select Municipality</option>
                                                <?php $__currentLoopData = $munData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($mun->id); ?>"
                                                        <?php echo e($mun->id==$addressData->permanent_municipality ?? old('permanent_municipality')==$mun->id ? 'selected':''); ?>>
                                                        <?php echo e($mun->municipality_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group mb-2">
                                            <label for="permanent_tole">Tole (Optional)</label>
                                            <input type="text" name="permanent_tole" id="permanent_tole"
                                                   value="<?php echo e($addressData->permanent_tole ?? old('permanent_tole')); ?>"
                                                   class="form-control">
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"> Temporary Address</h5>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input type="checkbox" id="same" name="save" value="same">
                                            <label for="same">Same as permanent address </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-2">
                                            <label for="temporary_country">Country:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('temporary_country')); ?></a>

                                            </label>
                                            <select name="temporary_country" id="temporary_country"
                                                    class="form-control">
                                                <option value="" selected readonly>Select Country</option>
                                                <?php $__currentLoopData = $countryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($country->id); ?>"
                                                        <?php echo e($country->id==$addressData->temporary_country ?? old('temporary_country')==$country->id ? 'selected':''); ?>>
                                                        <?php echo e($country->country_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-2">
                                            <label for="temporary_province">Province:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('temporary_province')); ?></a>
                                            </label>
                                            <select name="temporary_province" id="temporary_province"
                                                    class="form-control">
                                                <option value="" selected readonly>Select Province</option>
                                                <?php $__currentLoopData = $provinceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($province->id); ?>"
                                                        <?php echo e($province->id==$addressData->temporary_province ?? old('temporary_province')==$province->id ? 'selected':''); ?>>
                                                        <?php echo e($province->province_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-2">
                                            <label for="temporary_district">District:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('temporary_district')); ?></a>
                                            </label>
                                            <select name="temporary_district" id="temporary_district"
                                                    class="form-control">
                                                <option value="" selected readonly>Select District</option>
                                                <?php $__currentLoopData = $districtData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($district->id); ?>"
                                                        <?php echo e($addressData->temporary_district==$district->id ?? old('temporary_district')==$district->id ? 'selected':''); ?>>
                                                        <?php echo e($district->district_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-2">
                                            <label for="temporary_municipality">Municipality:
                                                <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('temporary_municipality')); ?></a>
                                            </label>
                                            <select name="temporary_municipality" id="temporary_municipality"
                                                    class="form-control">
                                                <option value="" selected readonly>Select Municipality</option>
                                                <?php $__currentLoopData = $munData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($mun->id); ?>"
                                                        <?php echo e($mun->id==$addressData->temporary_municipality ?? old('temporary_municipality')==$mun->id ? 'selected':''); ?>>
                                                        <?php echo e($mun->municipality_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group mb-2">
                                            <label for="temporary_tole">Tole (Optional)</label>
                                            <input type="text" name="temporary_tole"
                                                   id="temporary_tole"
                                                   value="<?php echo e($addressData->temporary_tole ?? old('temporary_tole')); ?>"
                                                   class="form-control">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 mt-3 mb-4">
                        <a href="<?php echo e(route('register.step.one')); ?>" class="btn btn-info">Previous</a>
                        <button class="btn btn-success">Next</button>
                    </div>
                </div>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/register/register-step-two.blade.php ENDPATH**/ ?>