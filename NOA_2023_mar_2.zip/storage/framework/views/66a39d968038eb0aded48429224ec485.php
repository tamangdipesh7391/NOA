
<?php $__env->startSection('content'); ?>
    <div class="container mb-5 mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1 class="is-size-1">Register New Account</h1>
                <?php echo e($errors); ?>

            </div>
        </div>
        <div class="row">
            <form action="<?php echo e(route('register.step.three')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-4"> Documents Details:
                                <a style="color: red;text-decoration: none;">Citizenship or driving license or
                                    passport</a>
                            </h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="citizenship_no">Citizenship no:
                                            <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('citizenship_no')); ?></a>
                                        </label>
                                        <input type="text" name="citizenship_no" id="citizenship_no"
                                               placeholder="citizenship no"
                                               value="<?php echo e(old('citizenship_no')); ?>"
                                               class="form-control">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="qualification">Qualification:
                                            <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('qualification')); ?></a>
                                        </label>
                                        <input type="text" name="qualification" id="qualification"
                                               value="<?php echo e(old('qualification')); ?>"
                                               class="form-control">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="year_of_graduation">Graduation Year:
                                            <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('year_of_graduation')); ?></a>
                                        </label>
                                        <input type="date" name="year_of_graduation" id="year_of_graduation"
                                               value="<?php echo e(old('year_of_graduation')); ?>"
                                               class="form-control">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="university">University:
                                            <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('university')); ?></a>
                                        </label>
                                        <input type="text" name="university" id="university"
                                               value="<?php echo e(old('university')); ?>"
                                               class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="">Front Side:
                                            <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('front_size')); ?></a>
                                        </label>
                                        <input type="file" name="front_size" id="front_size" class="form-control">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="back_size">Back Side:
                                            <a style="color: red;text-decoration: none;">* <?php echo e($errors->first('back_size')); ?></a>
                                        </label>
                                        <input type="file" name="back_size" id="back_size" class="form-control">
                                    </div>

                                    <div class="form-group mb-3">
                                        <label for="image">Photo (Optional) </label>
                                        <input type="file" name="image" id="image" class="form-control">
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <div class="col-md-12 mt-4">
                    <a href="<?php echo e(route('register.step.two')); ?>" class="btn btn-info">Previous</a>
                    <button class="btn btn-success">Create Account</button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/optometrynepal/demo.optometrynepal.org/resources/views/frontend/pages/register/register-step-three.blade.php ENDPATH**/ ?>